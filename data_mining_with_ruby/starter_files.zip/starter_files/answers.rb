# require the library


# define your variables


# itereate over the csv file and iterate values


# NOTES:
#     total = yes + no
#     percentage_who_dont = no / total.to_f
#     percentage_who_dont = percentage_who_dont * 100
#     percentage_who_dont = percentage_who_dont.round(2)
#     puts percentage_who_dont.to_s + "% people do not eat steak"


# write a function


# call the function with each of the ranges
# variables being compared!