m = [
    [   # clear
        "Alrighty, no wrong answers yet. Lets help our friend by discovering the word!",
        "This is your chance to not hang a stick figure. All it takes is good guessing skills",
        "Here's hoping our friend is lucky! I know you have his best interests at heart"
    ],
    [  # noose
        "Don't worry, it's just one wrong answer. I think our friend is still okay.",
        "I think it's fine. One wrong answer isn't too bad",
        "Don't worry. This is your first wrong answer."
    ],
    [  # head
        "Don't be too hard on yourself. You've got five more guesses.",
        "You'll be fine. Our friend will be fine.",
        "Try not to think of it as a wrong answer... You'll get 'em next time."
    ],
    [  # body
        "Everything is fine. You've got plenty of chances.",
        "You're doing great. Don't give up. It just gets easier from here.",
        "Don't lose your head. Our friend is still pretty much okay."
    ],
    [  # left arm
        "Now you might want to take your time. We don't want our friend to lose his head.",
        "Lets take a breath. Now its starting to get real.",
        "You're still okay... I think... Yeah, it's fine"
    ],
    [  # right arm
        "I don't want to alarm you, but our friend can't affort many more incorrect answers.",
        "You aren't trying to hang our friend, right? He's a good guy",
        "Uh oh, Its times like these when you wonder if you've made the right choices. Deep breaths..."
    ],
    [  # left leg
        "I'm starting to think that you don't care about our friend...",
        "I have to ask: You are trying to get the right answer, aren't you?",
        "A fictional, stick figures life hangs in the balance! Oh the humanity!"
    ],
    [  # right leg leg
        "Blerg! Our friend breath his last... Oh well, luckily he isn't real",
        "He trusted us! Our friend is realeased from this mortal coil! Just kidding, he was never alive to begin with.",
        "I never thought I'd be saddened by the death of fourteen ascii characters. Sigh..."
    ]
]
